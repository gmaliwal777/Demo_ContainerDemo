//
//  BokuViewController.m
//  ContainerDemo
//
//  Created by Ghanshyam on 8/20/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "BokuViewController.h"
#import "AppDelegate.h"
#import <objc/runtime.h>


@interface BokuViewController ()

@end

#define OFFSET 150.0f

@implementation BokuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
 
}

/**
 *  Initialize Container Controller
 *
 *  @param leftViewController : LeftViewController
 *  @param mainViewController : MainViewController
 *
 *  @return : Container Controller instance
 */
-(id)initWithRootViewController:(UIViewController *)leftViewController mainViewController:(UIViewController *)mainViewController{
    
    self = [super initWithNibName:@"BokuViewController" bundle:[NSBundle mainBundle]];
    
    if (self) {
        
        self.leftViewController = leftViewController;
        
        self.mainViewController = mainViewController;
        
        [self addChildViewController:mainViewController];
        
        UIView *rootView = mainViewController.view;
        rootView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
        CGRect frame = self.view.frame;
        rootView.frame = frame;
        [self.view addSubview:rootView];
        
        [mainViewController didMoveToParentViewController:self];
        
    }
    
    return self;
}

/**
 *  Used to create next container transition
 */
-(void)makeNextTransition{
    UIViewController *childController = (UIViewController *)[self.childViewControllers lastObject];
    if (childController == _leftViewController) {
        //Move to Root Controller
        [self showMainController];
    }else if (childController == _mainViewController){
        //Move to Left Controller;
        [self showLeftController];
    }
}

/**
 *  Used to show left view controller
 */
-(void)showLeftController{
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
    
    
    _leftViewController.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    
    [_mainViewController willMoveToParentViewController:nil];
    
    [self addChildViewController:_leftViewController];
    
    CGRect frameChange = _mainViewController.view.frame;
    frameChange.origin.x = 150.0f;
    
    [self transitionFromViewController:_mainViewController toViewController:_leftViewController duration:1.0 options:0 animations:^{
        
        _mainViewController.view.frame = frameChange;
        
        [self.view addSubview:_mainViewController.view];
        
    } completion:^(BOOL finished) {
        [_mainViewController removeFromParentViewController];
        
        [_leftViewController willMoveToParentViewController:self];
        
        [self.view addSubview:_mainViewController.view];
        
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    }];
}


/**
 *  Used to show root view controller
 */
-(void)showMainController{
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
    
    
    [_leftViewController willMoveToParentViewController:nil];
    
    [self addChildViewController:_mainViewController];
    
    CGRect frameChange = _mainViewController.view.frame;
    frameChange.origin.x = 0.0f;
    
    [self transitionFromViewController:_leftViewController toViewController:_mainViewController duration:1.0 options:0 animations:^{
        
        _mainViewController.view.frame = frameChange;
        
        [self.view addSubview:_mainViewController.view];
        
    } completion:^(BOOL finished) {
        [_leftViewController removeFromParentViewController];
        
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
