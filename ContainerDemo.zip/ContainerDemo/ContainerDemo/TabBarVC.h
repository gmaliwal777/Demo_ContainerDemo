//
//  TabBarVC.h
//  ContainerDemo
//
//  Created by Ghanshyam on 8/21/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarVC : UITabBarController{
    
    /**
     *  Boolean identifiers say that viewWillAppear , viewWillDisApppear , viewDidAppear , viewDidDisAppear call is due to context lifecycle.
     */
    BOOL    isItLifeCycleEvent;
}

@end
