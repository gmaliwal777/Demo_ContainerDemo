//
//  TabBarVC.m
//  ContainerDemo
//
//  Created by Ghanshyam on 8/21/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "TabBarVC.h"

@interface TabBarVC ()

@end

@implementation TabBarVC


#pragma mark -- Super Class Methods

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    
    if (isItLifeCycleEvent) {
        if (self.selectedViewController) {
            [self.selectedViewController viewWillAppear:animated];
        }else{
            [super viewWillAppear:animated];
        }
    }
    
}

-(void)viewDidAppear:(BOOL)animated{
    
    if (isItLifeCycleEvent) {
        if (self.selectedViewController) {
            [self.selectedViewController viewDidAppear:animated];
        }else{
            [super viewDidAppear:animated];
        }
    }
    isItLifeCycleEvent = NO;
}

-(void)viewWillDisappear:(BOOL)animated{
    if (isItLifeCycleEvent) {
        if (self.selectedViewController) {
            [self.selectedViewController viewWillDisappear:animated];
        }else{
            [super viewWillDisappear:animated];
        }
    }
    
}



-(void)viewDidDisappear:(BOOL)animated{
    if (isItLifeCycleEvent) {
        if (self.selectedViewController) {
            [self.selectedViewController viewDidDisappear:animated];
        }else{
            [super viewDidDisappear:animated];
        }
    }
    isItLifeCycleEvent = NO;
}


-(void)willMoveToParentViewController:(UIViewController *)parent{
    isItLifeCycleEvent = YES;
}


@end
