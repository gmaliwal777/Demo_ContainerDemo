//
//  BokuViewController.h
//  ContainerDemo
//
//  Created by Ghanshyam on 8/20/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BokuViewController : UIViewController{
    
}

/**
 *  Reference to left view controller
 */
@property (nonatomic,strong) UIViewController   *leftViewController;


/**
 *  Reference to main view controller
 */
@property (nonatomic,strong) UIViewController   *mainViewController;


/**
 *  Initialize Container Controller
 *
 *  @param leftViewController : LeftViewController
 *  @param mainViewController : MainViewController
 *
 *  @return : Container Controller instance
 */
-(id)initWithRootViewController:(UIViewController *)leftViewController mainViewController:(UIViewController *)mainViewController;


/**
 *  Used to create next container transition
 */
-(void)makeNextTransition;


@end
