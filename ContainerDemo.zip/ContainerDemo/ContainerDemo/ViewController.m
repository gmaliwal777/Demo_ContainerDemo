//
//  ViewController.m
//  ContainerDemo
//
//  Created by Ghanshyam on 8/20/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import "BokuViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSLog(@"vc viewWillAppear");
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    NSLog(@"vc viewWillDisappear");
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    NSLog(@"vc viewDidAppear");
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    NSLog(@"vc viewDidDisappear");
}


-(IBAction)moveToMain{
    
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    BokuViewController *bokuVC = (BokuViewController *)appdelegate.containerController;
    [bokuVC makeNextTransition];
}


@end

