//
//  SecondVC.m
//  ContainerDemo
//
//  Created by Ghanshyam on 8/21/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "SecondVC.h"
#import "AppDelegate.h"
#import "BokuViewController.h"

@interface SecondVC ()

@end

@implementation SecondVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSLog(@"SecondVC viewWillAppear");
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    NSLog(@"SecondVC viewWillDisappear");
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    NSLog(@"SecondVC viewDidAppear");
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    NSLog(@"SecondVC viewDidDisappear");
}

-(IBAction)moveToLeft{
    
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    BokuViewController *bokuVC = (BokuViewController *)appdelegate.containerController;
    [bokuVC makeNextTransition];
}


@end
